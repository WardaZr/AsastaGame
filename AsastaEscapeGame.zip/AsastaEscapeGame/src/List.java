public class List {
    /*
    yang udah :
    1. ambil, buang, pakai item
    2. pindah lantai dan ruangan
    3. masuk dan keluar ruangan
    4. cctv
    5. misi 1
    6. revisi lihat item
    7. ajak Npc
    8. Bertarung
    7. kunci
    9. rakit item
    10. npcSerang
    11. aksi map
    12. buat objek keseluruhan
    13. narasi setiap misi, narasi awal,
    14. merapikan objek ke posisi sebennarnya (sesuai cerita yang di buat)

    yang belum :


    9. review
     */

}
